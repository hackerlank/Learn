#include "loginTimeTick.h"
#include "flyer.h"
#include "taskManager.h"
#include "loginServer.h"

Time LoginTimeTick::s_time;

LoginTimeTick::LoginTimeTick() : Thread("服务器时间线程"),m_secClock(1000),m_minClock(60*1000),m_hourClock(60*60*1000),m_halfHourClock(30*60*1000)
{
}

void LoginTimeTick::run()
{
    while(!isFinal())
    {
        s_time.now();
        if(m_hourClock(s_time))
        {
            char fileName[100] = {0};
            snprintf(fileName,sizeof(fileName),"log/login-%02u.log",LoginServer::getInstance().getServerID());
            Flyer::changeLogger(fileName,s_time.sec());
        }
        if(m_minClock(s_time))
        {
            TaskManager::getInstance().sendHeartMsg();
        }
    }
}

