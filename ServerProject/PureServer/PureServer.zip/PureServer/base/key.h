#ifndef KEY_H
#define KEY_H

unsigned long hashKey(unsigned int key1,unsigned int key2);

unsigned int hashKey(unsigned short key1,unsigned short key2);

unsigned short hashKey(unsigned char key1,unsigned char key2);

#endif
