#include <iostream>
using namespace std;
int mian()
{
    return 0;
}
